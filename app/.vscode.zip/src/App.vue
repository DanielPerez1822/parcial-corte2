<template>
  <ion-app>
    <ion-router-outlet />
    <!-- <PersonaForm tipoUsuario="cliente" @guardar="handleGuardar" /> -->
  </ion-app>
</template>

<script setup lang="ts">
import { IonApp, IonRouterOutlet } from '@ionic/vue';
// import PersonaForm from "./components/persona/PersonaForm.vue";
</script>
